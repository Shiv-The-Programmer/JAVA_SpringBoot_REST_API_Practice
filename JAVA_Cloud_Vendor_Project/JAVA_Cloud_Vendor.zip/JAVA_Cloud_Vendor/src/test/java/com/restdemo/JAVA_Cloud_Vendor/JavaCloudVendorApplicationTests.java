package com.restdemo.JAVA_Cloud_Vendor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaCloudVendorApplicationTests {

	@Test
	void contextLoads() {
	}

}
